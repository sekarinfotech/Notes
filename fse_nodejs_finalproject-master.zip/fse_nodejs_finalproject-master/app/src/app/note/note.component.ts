import { Component, Input } from '@angular/core';

import { Note } from './../note';
import { RouterService } from './../services/router.service';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent {

  @Input()
  note: Note;

  @Input() sharednote: Note;

  constructor(private routerService: RouterService) {}

  ngOnInit() {
    console.log(this.note)
  }

  openEditView() {
    // Route to the edit view while clicking on note
    this.routerService.routeToEditNoteView(this.note.id);
  }

}
