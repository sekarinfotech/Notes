import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Note } from '../note';
import { Register } from '../register';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { AuthenticationService } from './authentication.service';

import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class NotesService {

  notes: Array<Note>;
  availableUsers:Array<Register>;
  availableUsersSubject: BehaviorSubject<Array<Register>>;
  notesSubject: BehaviorSubject<Array<Note>>;
  token: any;
  userid: string;
  userIdFromLocalStorage: string;
  SharedNotes: Array<Note>;
  SharedNotesSubject: BehaviorSubject<Array<Note>>;

  constructor(private http: HttpClient, private authService: AuthenticationService) {
    this.notes = [];
    this.notesSubject = new BehaviorSubject(this.notes);
    this.availableUsers = [];
    this.availableUsersSubject = new BehaviorSubject(this.availableUsers);
    this.SharedNotes = [];
    this.SharedNotesSubject = new BehaviorSubject(this.SharedNotes);
    this.token = this.authService.getBearerToken();
    this.userid = this.authService.getUserID();
  }

  fetchNotesFromServer() {
    this.userIdFromLocalStorage = localStorage.getItem('userid');
    this.userid = this.userIdFromLocalStorage ? this.userIdFromLocalStorage : this.userid;
    // to fetch the notes from server
    return this.http.get<Array<Note>>('http://localhost:3000/api/v1/notes?userId='+this.userid, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
    })
    .subscribe( notes => {
      this.notes = notes;
      this.notesSubject.next(this.notes);
    },
    err => {
      return Observable.throw(err);
    });
  }

  fetchAvailableUsersFromServer(){
    this.userid = this.userIdFromLocalStorage ? this.userIdFromLocalStorage : this.userid;
    // to fetch the notes from server
    return this.http.get<Array<Register>>('http://localhost:3000/api/v1/users/availableUser?id='+this.userid, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
    })
    .subscribe( users => {
      this.availableUsers = users;
      this.availableUsersSubject.next(this.availableUsers);
    },
    err => {
      return Observable.throw(err);
    });
  }


  getAvailableUsers(): BehaviorSubject<Array<Register>> {
    return this.availableUsersSubject;
  }

  getNotes(): BehaviorSubject<Array<Note>> {
    return this.notesSubject;
  }

  getSharedNotes(): BehaviorSubject<Array<Note>> {
    return this.SharedNotesSubject;
  }

  addNote(note: Note): Observable<Note> {
    return this.http.post<Note>('http://localhost:3000/api/v1/notes?userId='+this.userid, note, {
      headers : new HttpHeaders()
      .set('Authorization', `Bearer ${this.token}`)
    })
    .do (addNote => {
      this.notes.push(addNote);
      this.notesSubject.next(this.notes);
    })
    .catch(err => {
      return Observable.throw(err);
    });
  }

  editNote(note: Note): Observable<Note> {
    return this.http.put<Note>(`http://localhost:3000/api/v1/notes/${note.id}`, note, {
      headers : new HttpHeaders()
      .set('Authorization', `Bearer ${this.token}`)
    }).do(editNote => {
      // Update the edited notes by comparing the noteId
      const noteValue = this.notes.find(notes => notes.id === editNote.id);
      Object.assign(noteValue, editNote);
      this.notesSubject.next(this.notes);
    });
  }

  getNoteById(noteId): Note {
    // Get the note details by passing the noteId
    const noteValue = this.notes.find(note => note.id === noteId);
    return Object.assign({}, noteValue);
  }

  fetchSharedNotesFromServer(){
    this.userid = this.userIdFromLocalStorage ? this.userIdFromLocalStorage : this.userid;
    return this.http.get<Array<Note>>('http://localhost:3000/api/v1/notes/sharedNotes?userId='+this.userid, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
    })
    .subscribe( notes => {
      this.SharedNotes = notes;
      this.SharedNotesSubject.next(this.SharedNotes);
    },
    err => {
      return Observable.throw(err);
    });
  }

  uploadNotes(file: File): Observable<any> {
    const endpoint = 'http://localhost:3000/api/v1/notes/bulk?userId='+this.userid;
    const formData: FormData = new FormData();
    formData.append('fileKey', file, file.name);
    let header = new HttpHeaders().set('Authorization', `Bearer ${this.token}`);
    header.append('Content-Type', 'multipart/form-data');
    return this.http.post(endpoint, formData, {
      headers : header
    })
  }

}
