import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormGroupDirective } from '@angular/forms';
import { ViewChild } from '@angular/core';
import { Register } from '../register';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  user: Register;
  submitMessage: String;
  username = new FormControl('', [Validators.required]);
  password = new FormControl('', [Validators.required]);
  firstName = new FormControl('', [Validators.required]);
  lastName = new FormControl('', [Validators.required]);
  
  constructor(private authenticationService: AuthenticationService,
      private routerService: RouterService) {}

      saveUser() {
        const userData = new Register(this.username.value, this.password.value);       
        if (this.username.valid && this.password.valid) {
          this.authenticationService.saveUser(userData).subscribe(
            response => {
              this.submitMessage= "User created successfully!.. Try logging in";
              //this.routerService.routeToLogin();
            },
            err => {
              // get the error message based on the status
              this.submitMessage= "User creation failed...";
              //this.submitMessage = (err.status === 403) ? err.error.message : err.message;
            }
          );
        }
      }
      login(){
        this.routerService.routeToLogin();
      }
      getUserNameErrorMessage() {
        // Required error message for username
        return this.username.hasError('required') ? 'You must enter a Username' : '';
      }
      getPasswordErrorMessage() {
        // Required error message for password
        return this.password.hasError('required') ? 'You must enter a password' : '';
      }
     
}
