import { Component } from '@angular/core';
import { Register } from './../register';
import { Note } from './../note';
import { NotesService } from './../services/notes.service';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent {
  errMessage: string;
  note: Note = new Note();
  notes: Array<Note> = [];
  users: Array<Register>;
  uploadedFile: any;
  fileToUpload: File = null;
  constructor(private notesService: NotesService) {
    this.notesService.fetchAvailableUsersFromServer();
    this.notesService.getAvailableUsers().subscribe(
      data => this.users = data
    )
  }

  // Calls a service and saves the note to db.json file
   insertNotes() {
    const title = this.note.title.trim();
    const text = this.note.text.trim();
    const sharewith = this.note.sharewith;
    if (title === '' || text === '') {
      // add the error message when fields are empty
      this.errMessage = 'Title and Text both are required fields';
    } else {
      // add notes to service
      this.notes.push(this.note);
      this.notesService.addNote(this.note).subscribe(
        data => {
          this.errMessage = '';
        },
        err => {
          // remove the added note if there is any error
          this.notes.pop();
          this.errMessage = err.message;
        }
      );
    }
    this.note = new Note();
  }

  // Calls a service and saves the note to db.json file
  uploadNotes() {
    if (this.fileToUpload === null) {
      // add the error message when fields are empty
      this.errMessage = 'Title and Text both are required fields';
    } else {
      // add notes to service
       this.notesService.uploadNotes(this.fileToUpload).subscribe(
        data => {
          window.location.reload();
          
        }
      );
    }
  }

  setNotes(file : FileList) {
    this.fileToUpload = file.item(0);
  }
}
