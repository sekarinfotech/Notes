//  Test Configuration Object


const register_user = {
	username:"Swapna",
	password:"password"
};
const reg_user_success_res = {
	user: {
		userName:"Swapna"
	}
};
const already_exist = {
	message : "username is already exist"
};
const login_with_wrong_pwd = {
	username: "Swapna",
	password: "password$"
}
const error_messages = {
	user_already_exist : "username is already exist",
	incorrect_pwd : "Passwords is incorrect",
	incorrect_uname : "You are not registered user"
}
const tokenConfig = {
  secretKey: 'Cognizant'
}
const USER_1 = {
	username:"test1",
	password:"password"
};
const USER_2 = {
	username:"test2",
	password:"password"
};
const USER_3 = {
	username:"test3",
	password:"password"
};
const note_1 = {
        title: "Bill Reminder",
        text: "Electrcity bill"
    }
const note_2 = {
        title: "Anniversary reminder",
        text: "Sister's wedding anniversary"
    }
module.exports = {
	tokenConfig,
	register_user,
	reg_user_success_res,
	error_messages,
	USER_1,
	USER_2,
	USER_3,
	note_1,
	note_2,
	login_with_wrong_pwd
}

