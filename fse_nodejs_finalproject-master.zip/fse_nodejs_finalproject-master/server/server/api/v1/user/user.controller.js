const userService =  require('./user.services')
// Handler to register new user
const addUser = (userInfo) => {
	return userService.addUser(userInfo);
}
// Handler to verify user
const verifyUser = (userInfo) => {
	return userService.verifyUser(userInfo);
}

const availableUser = (userInfo) => {
  return userService.availableUser(userInfo);
}
module.exports = {
  addUser,
  verifyUser,
  availableUser
}