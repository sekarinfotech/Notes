// const jwt = require('jsonwebtoken');
// const { authConfig } = require('../../../config').appConfig;
let userDAO = require('./user.dao');
function verifyUser(userInfo) {
	return userDAO.verifyUser(userInfo);
}
function addUser(userInfo) {
	return userDAO.addUser(userInfo);
}
function availableUser(userInfo) {
	return userDAO.availableUser(userInfo);
}
module.exports = {
  addUser,
  verifyUser,
  availableUser
}