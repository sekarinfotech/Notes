let mongoose = require('mongoose');
// define the userSchema model
let Schema = mongoose.Schema;
const userSchema = new Schema({
  userId: {
    type: String,
    required: true
  },
  userName: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  }
});
module.exports = mongoose.model('users', userSchema);