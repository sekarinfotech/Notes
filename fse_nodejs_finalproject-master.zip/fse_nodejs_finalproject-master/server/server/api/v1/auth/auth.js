
var jwt = require('jsonwebtoken');
function signToken(payload, secret, expireIn, callback) {
	jwt.sign(payload, secret, expireIn, callback);
}
function verifyToken(token, secret, callback) {
    jwt.verify(token, secret, callback)
}
module.exports = {
  signToken,
  verifyToken
}