const router = require('express').Router();
const notesCtrl = require('./notes.controller');
const jsonfile = require('jsonfile');
let auth = require('../auth');
const { tokenConfig } = require('../../../config').appConfig;
router.use(function(req, res, next) {
  const authorizationHeader = req.get('Authorization');
  if (!authorizationHeader) {
    res.status(403).send('Not authenticated');
  }
  else {
  const token = authorizationHeader.replace('Bearer ', '');
  auth.verifyToken(token, tokenConfig.secretKey, (err, decoded) => {
    if(err) {
        res.status(403).send('invalid token');
      } else {
        next();
    }
  });
}
});
// api to add a note
router.post('/', (req, res, next) => {
  let note = req.body;
  let userId = req.query.userId;
  try {
      notesCtrl.addNote(userId, note).then((response) => {
        console.log(response)
      res.status(response.status).send(response.note);
    },
    (err) => {
      console.log(err)
      res.status(err.status).send(err);
    });
  } catch (err) {
    console.log(err)
    res.send({message: 'Failed to complete request'})
  }
});
// api to get all notes into database
router.get('/', (req, res, next) => {
  let userId = req.query.userId;
  try {
    notesCtrl.getNotes(userId).then((response) => {
      res.status(response.status).send(response.notes);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});
// api to update a note
router.put('/:noteId', (req, res, next) => {
  try {
    let userId = req.query.userId;
    let noteId = req.params.noteId;
    let editedNote =  req.body;
    notesCtrl.updateNote(noteId, editedNote).then((response) => {
      res.status(response.status).send(response.updatedNote);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});


// api to verify sharedNotes
router.get('/sharedNotes', (req, res, next) => {
  try {
    let userInfo =  req.query.userId;
    console.log(userInfo + "test")
    notesCtrl.sharedNotes(userInfo).then((response) => {
      res.status(response.status).send(response);
    },
    (err) => {
      res.status(err.status).send({message:err.message});
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

router.post('/bulk', (req, res, next) => {
  console.log("user id:"+ req.query.userId);
  console.log("user files:"+ JSON.stringify(req.body));
  jsonfile.readFile(req.files.fileKey.path, function (err, obj) {
    if (err) console.log(err)
    console.log(obj);
    try {
      let userId = req.query.userId;
      obj.forEach(element => {
        notesCtrl.addNote(userId, element).then((response) => {
        res.status(response.status).send(response.note);
      });
      
    },
    (err) => {
      console.log(err)
      res.status(err.status).send(err);
    })
    } catch (err) {
      res.send({message: 'Failed to complete request'})
    }
    
   });
  
});


module.exports = router;