const bodyParser = require('body-parser');
const cors = require('cors')
const api = require('./api/v1');
const db = require('./db');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('../../swagger.json');
const express = require('express');
const formidable = require('express-formidable');
const formData = require("express-form-data");


// create db connection
const connectToDatabase = () => {
  db.createMongoConnection();
}
// settting application middleware with basic modules
const setAppMiddleware = (app) => {
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({extended:true,limit: '20MB',parameterLimit:10000}));
  const options = {   
    autoClean: true
  };
   
  // parse data with connect-multiparty. 
  app.use(formData.parse(options));
  // delete from the request all empty files (size == 0)
  app.use(formData.format());
  // change the file objects to fs.ReadStream 
  app.use(formData.stream());
  // union the body and the files
  app.use(formData.union());

  app.use(cors());
}
// api configuration
const apiSetUp = (app) => {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
  app.use('/api/v1', api);
}
module.exports = {
  connectToDatabase,
  setAppMiddleware,
  apiSetUp
}