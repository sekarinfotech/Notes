export class Register {
  username: String;
  password: String;

  constructor(username, password) {
    this.username = username;
    this.password = password;
  }
}

