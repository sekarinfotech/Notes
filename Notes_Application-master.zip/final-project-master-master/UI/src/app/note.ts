import { Register} from './register';
export class Note {
  id: string;
  title: string;
  text: string;
  state: string;
  sharewith: Array<Register>;
  favourite: boolean;
  dueAt: string;

  constructor() {
    this.title = '';
    this.text = '';
    this.state = 'not-started';
    this.sharewith = [];
    this.favourite = false;
    this.dueAt = '';
  }
}
