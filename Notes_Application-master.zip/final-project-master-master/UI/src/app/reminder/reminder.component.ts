import { NotesService } from './../services/notes.service';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Note } from '../note';

@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.css']
})
export class ReminderComponent implements OnInit {
  note: Note;
  errMessage: string;

  constructor(private dialogRef: MatDialogRef<ReminderComponent>,
              @Inject(MAT_DIALOG_DATA) private data: any,
              private notesService: NotesService) {
              }

  ngOnInit() {
    // While opening the edit dialog get the note details by passing the noteId
    this.note = this.notesService.getNoteById(this.data.noteId);   
  }

  onSave() {
    // Close the edit dialog while clicking on save
    this.notesService.setReminder(this.note, this.note.dueAt).subscribe(editNote => {
      this.dialogRef.close();
    },
    err => {
      this.errMessage = err.message;
    });
  }
}
