import { Component, OnInit } from '@angular/core';

import { Note } from './../note';
import { Register } from './../register';
import { NotesService } from './../services/notes.service';
import { ReminderService } from './../services/reminder.service';


@Component({
  selector: 'app-note-view',
  templateUrl: './note-view.component.html',
  styleUrls: ['./note-view.component.css']
})
export class NoteViewComponent implements OnInit {

  notes: Array<Note>;
  sharednotes: Array<Note>;
  errMessage: any;


  constructor(private notesService: NotesService, private reminderService: ReminderService) {}

  ngOnInit() {
    // populate the notes
    this.notesService.getNotes().subscribe(
      data => this.notes = data,
      err => this.errMessage = err.message
    );

    this.notesService.getSharedNotes().subscribe(
      data => this.sharednotes = data,
      err => this.errMessage = err.message
    );

    this.reminderService.checkReminder();   
  
  }
}
