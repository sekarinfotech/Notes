import { Component } from '@angular/core';

import { Note } from '../note';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-note-bulk-uploader',
  templateUrl: './note-bulk-uploader.component.html',
  styleUrls: ['./note-bulk-uploader.component.css']
})
export class BulkUploaderComponent {
  errMessage: string;
  uploadedFile: any;
  fileToUpload: File = null;

  constructor(private notesService: NotesService) {}

  // Calls a service and saves the note to db.json file
   uploadNotes() {
    if (this.fileToUpload === null) {
      // add the error message when fields are empty
      this.errMessage = 'Title and Text both are required fields';
    } else {
      // add notes to service
       this.notesService.uploadNotes(this.fileToUpload).subscribe(
        data => {
          window.location.reload();
          
        }
      );
    }
  }

  setNotes(file : FileList) {
    this.fileToUpload = file.item(0);
  }
}
