import { NotesService } from './../services/notes.service';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Note } from '../note';

@Component({
  selector: 'app-edit-note-view',
  templateUrl: './edit-note-view.component.html',
  styleUrls: ['./edit-note-view.component.css']
})
export class EditNoteViewComponent implements OnInit {
  note: Note;
  states: Array<string> = ['not-started', 'started', 'completed'];
  errMessage: string;

  constructor(private dialogRef: MatDialogRef<EditNoteViewComponent>,
              @Inject(MAT_DIALOG_DATA) private data: any,
              private notesService: NotesService) {
              }

  ngOnInit() {
    // While opening the edit dialog get the note details by passing the noteId
    this.note = this.notesService.getNoteById(this.data.noteId);
    console.log(this.data, this.note);
  }

  onSave() {
    // Close the edit dialog while clicking on save
    this.notesService.editNote(this.note).subscribe(editNote => {
      this.dialogRef.close();
    },
    err => {
      this.errMessage = err.message;
    });
  }
}
