import { Component, Input } from '@angular/core';

import { Note } from './../note';
import { RouterService } from './../services/router.service';

@Component({
  selector: 'app-snote',
  templateUrl: './sharednote.component.html',
  styleUrls: ['./sharednote.component.css']
})
export class SharedNoteComponent {

  @Input()
  note: Note;

  constructor(private routerService: RouterService) {}

  ngOnInit() {
    console.log("Shared notes");
    console.log(this.note)
  }

}
