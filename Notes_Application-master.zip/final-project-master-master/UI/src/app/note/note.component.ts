import { Component, Input } from '@angular/core';

import { Note } from './../note';
import { Register } from './../register';
import { RouterService } from './../services/router.service';
import { NotesService } from './../services/notes.service';


import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ReminderComponent } from './../reminder/reminder.component';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent {

  @Input()
  note: Note;
  @Input()
  snote: Note;

  users: Array<Register>;

  constructor(private routerService: RouterService, private noteService: NotesService, private dialog: MatDialog) {
    this.noteService.getAvailableUsers().subscribe(
      data => this.users = data
    )
  }

  ngOnInit() {
    console.log(this.note)
  }

  openEditView() {
    // Route to the edit view while clicking on note
    this.routerService.routeToEditNoteView(this.note.id);
  }

  setFavorite() {
     let _that = this;
     this.noteService.setfav(this.note).subscribe(editNote => {
        _that.note = editNote;
     });
  }

  deleteNote() {
    this.noteService.deleteNote(this.note).subscribe();
  }

  shareNote() {
     let _that = this;
     this.noteService.shareNotes(this.note, this.note.sharewith).subscribe(sharedNote => {
        _that.note = sharedNote;
     });
  }

  setReminder() {
   this.dialog.open(ReminderComponent, {
      data: { noteId: this.note.id }
    })
  }

}
