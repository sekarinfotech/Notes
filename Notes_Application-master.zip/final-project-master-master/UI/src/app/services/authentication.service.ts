import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class AuthenticationService {
  private auth_url = 'http://localhost:3000/';

  constructor(private httpClient: HttpClient) {}

  // to check the user authentication
  authenticateUser(data) {
    return this.httpClient.post(`${this.auth_url}api/v1/users/login`, data);
  }

  regiesterUser(data) {
    return this.httpClient.post(`${this.auth_url}api/v1/users/register`, data);
  }
// set the token to localstorage
  setBearerToken(token) {
    localStorage.setItem('bearerToken', token);
  }
// Get the token from the local storage
  getBearerToken() {
    return localStorage.getItem('bearerToken');
  }

  // set the userid to localstorage
  setUserID(userid) {
    localStorage.setItem('userid', userid);
  }
// Get the userid from the local storage
  getUserID() {
    return localStorage.getItem('userid');
  }

  removeAuthentication(){
    localStorage.clear();
  }

  // to validate if the user is authenticated or not
  isUserAuthenticated(token): Promise<boolean> {
    return this.httpClient.post(`${this.auth_url}api/v1/users/isAuthenticated`, {}, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${token}`)
    })
    .map((response) => response['isAuthenticated'])
    .toPromise();
  }
}
