import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Note } from '../note';
import { Register } from '../register';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { AuthenticationService } from './authentication.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable()
export class ReminderService {

  notes: Array<Note>;
  availableUsers: Array<Register>;
  availableUsersSubject: BehaviorSubject<Array<Register>>;
  notesSubject: BehaviorSubject<Array<Note>>;
  sharednotes: Array<Note>;
  sharednotesSubject: BehaviorSubject<Array<Note>>;
  token: any;
  userid: string;
  userIdFromLocalStorage: string;
  reminderInterval:number = 10000;

  constructor(private http: HttpClient, private authService: AuthenticationService, private snackBar: MatSnackBar) {
    this.notes = [];
    this.notesSubject = new BehaviorSubject(this.notes);
    this.token = this.authService.getBearerToken();
    this.userid = this.authService.getUserID();
  }

  getReminder(): Observable<Note[]> {
    this.userIdFromLocalStorage = localStorage.getItem('userid');
    this.userid = this.userIdFromLocalStorage ? this.userIdFromLocalStorage : this.userid;
    return this.http.get<Note[]>('http://localhost:3000/api/v1/notes/reminder?userId=' + this.userid,  {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${this.token}`)
    }).do(editNote => {
      // Update the edited notes by comparing the noteId
      /*const noteValue = this.notes.find(notes => notes.id === editNote.id);
      Object.assign(noteValue, editNote);
      this.notesSubject.next(this.notes);*/

      let date = new Date();
      let hours = date.getHours().toLocaleString();
      let minutes = date.getMinutes().toLocaleString();
      let compareDueAt = (hours.length == 1 ? '0'+hours: hours )+":"+minutes;
      let _that = this;
      editNote.forEach(function(obj){
        if(obj.dueAt === compareDueAt){
          let message = 'You have remainder set for note:' + obj.title;
           _that.snackBar.open(message, '', {
            duration: 2000
          });
        }

       });

      
     
    }).catch(err => {
      return Observable.throw(err);
    });
  }

  checkReminder(): void{    
    let _that = this;
    let reminder = setInterval(function(){
       _that.getReminder().subscribe();
    }, this.reminderInterval);
  }


}
