import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Note } from '../note';
import { Register } from '../register';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { AuthenticationService } from './authentication.service';

import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class NotesService {

  notes: Array<Note>;
  availableUsers: Array<Register>;
  availableUsersSubject: BehaviorSubject<Array<Register>>;
  notesSubject: BehaviorSubject<Array<Note>>;
  sharednotes: Array<Note>;
  sharednotesSubject: BehaviorSubject<Array<Note>>;
  token: any;
  userid: string;
  userIdFromLocalStorage: string;

  constructor(private http: HttpClient, private authService: AuthenticationService) {
    this.notes = [];
    this.notesSubject = new BehaviorSubject(this.notes);
    this.sharednotesSubject = new BehaviorSubject(this.sharednotes);
    this.availableUsers = [];
    this.availableUsersSubject = new BehaviorSubject(this.availableUsers);
    this.token = this.authService.getBearerToken();
    this.userid = this.authService.getUserID();
  }

  fetchNotesFromServer() {
    this.userIdFromLocalStorage = localStorage.getItem('userid');
    this.userid = this.userIdFromLocalStorage ? this.userIdFromLocalStorage : this.userid;
    // to fetch the notes from server
    return this.http.get<Array<Note>>('http://localhost:3000/api/v1/notes?userId=' + this.userid, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
    })
      .subscribe(notes => {
        this.notes = notes;
        this.notesSubject.next(this.notes);
      },
        err => {
          return Observable.throw(err);
        });
  }

  fetchSharedNotesFromServer() {
    this.userIdFromLocalStorage = localStorage.getItem('userid');
    this.userid = this.userIdFromLocalStorage ? this.userIdFromLocalStorage : this.userid;
    // to fetch the notes from server
    return this.http.get<Array<Note>>('http://localhost:3000/api/v1/notes/sharedNotes?userId=' + this.userid, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
    })
      .subscribe(notes => {
        this.sharednotes = notes;
        this.sharednotesSubject.next(this.sharednotes);
      },
        err => {
          return Observable.throw(err);
        });
  }

  fetchAvailableUsersFromServer() {
    this.userid = this.userIdFromLocalStorage ? this.userIdFromLocalStorage : this.userid;
    // to fetch the notes from server
    return this.http.get<Array<Register>>('http://localhost:3000/api/v1/users/availableUser?id=' + this.userid, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
    })
      .subscribe(users => {
        this.availableUsers = users;
        this.availableUsersSubject.next(this.availableUsers);
      },
        err => {
          return Observable.throw(err);
        });
  }

  getAvailableUsers(): BehaviorSubject<Array<Register>> {
    return this.availableUsersSubject;
  }

  getNotes(): BehaviorSubject<Array<Note>> {
    return this.notesSubject;
  }

  getSharedNotes(): BehaviorSubject<Array<Note>> {
    return this.sharednotesSubject;
  }

  setfav(note: Note): Observable<Note> {
    note.favourite = note.favourite ? !note.favourite : true;
    return this.editNote(note);
  }

  shareNotes(note: Note, users: any): Observable<Note> {
    note.sharewith = users;
    return this.editNote(note);
  }

  addNote(note: Note): Observable<Note> {
    return this.http.post<Note>('http://localhost:3000/api/v1/notes?userId=' + this.userid, note, {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${this.token}`)
    })
      .do(addNote => {
        this.notes.push(addNote);
        this.notesSubject.next(this.notes);
      })
      .catch(err => {
        return Observable.throw(err);
      });
  }

  editNote(note: Note): Observable<Note> {
    return this.http.put<Note>(`http://localhost:3000/api/v1/notes/${note.id}`, note, {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${this.token}`)
    }).do(editNote => {
      // Update the edited notes by comparing the noteId
      const noteValue = this.notes.find(notes => notes.id === editNote.id);
      Object.assign(noteValue, editNote);
      this.notesSubject.next(this.notes);
    }).catch(err => {
      return Observable.throw(err);
    });
  }

  deleteNote(note: Note): Observable<Note> {
    return this.http.delete<Note>(`http://localhost:3000/api/v1/notes/${note.id}`, {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${this.token}`)
    }).do(editNote => {
      var _that = this;
      this.notes.forEach(function (elem, index) {
        if (elem.id == note.id) {
          delete _that.notes[index];
        }
      });
      this.notesSubject.next(this.notes);
    }).catch(err => {
      return Observable.throw(err);
    });
  }

  getNoteById(noteId): Note {
    // Get the note details by passing the noteId
    const noteValue = this.notes.find(note => note.id === noteId);
    return Object.assign({}, noteValue);
  }

  uploadNotes(file: File): Observable<any> {
    const endpoint = 'http://localhost:3000/api/v1/notes/bulk?userId=' + this.userid;
    const formData: FormData = new FormData();
    formData.append('fileKey', file, file.name);
    let header = new HttpHeaders().set('Authorization', `Bearer ${this.token}`);
    header.append('Content-Type', 'multipart/form-data');
    return this.http.post(endpoint, formData, {
      headers: header
    })
  }

  setReminder(note: Note, dueAt: string): Observable<Note> {
    return this.http.post<Note>(`http://localhost:3000/api/v1/notes/reminder/${note.id}/${dueAt}`, note, {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${this.token}`)
    }).do(editNote => {
      // Update the edited notes by comparing the noteId
      /*const noteValue = this.notes.find(notes => notes.id === editNote.id);
      Object.assign(noteValue, editNote);
      this.notesSubject.next(this.notes);*/
      console.log(editNote);
    }).catch(err => {
      return Observable.throw(err);
    });
  }

}
