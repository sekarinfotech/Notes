import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

import { RouterService } from './../services/router.service';
import { AuthenticationService } from '../services/authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isNoteView;
isUserAuthenticated = true;
  constructor(private routerService: RouterService, private location: Location, private authService: AuthenticationService) {
    authService.getUserID() != null ? this.isUserAuthenticated = true : this.isUserAuthenticated = false;
  }

  ngOnInit() {
    this.isNoteView = (location.pathname.includes('/view/noteview')) ? true :
                      (location.pathname.includes('/view/listview')) ? false : true;
  }

  showListView() {
    this.isNoteView = false;
    this.routerService.routeToListView();
  }
  showNoteView() {
    this.isNoteView = true;
    this.routerService.routeToNoteView();
  }
  logout(){
    this.routerService.logout();
  }
}
