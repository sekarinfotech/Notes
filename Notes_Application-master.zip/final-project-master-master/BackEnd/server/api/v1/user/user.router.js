const router = require('express').Router();
let auth = require('../auth');
const { tokenConfig } = require('../../../config').appConfig;

const userCtrl = require('./user.controller');
// api to register new user
router.post('/register', (req, res, next) => {
  let userInfo = req.body;
  try {
    userCtrl.addUser(userInfo).then((response) => {
      res.status(response.status).send({userInfo:response.userInfo.userName});
    },
    (err) => {
      res.status(err.status).send({message:err.message});
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});
router.post('/isAuthenticated',(req, res, next) => {
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
  auth.verifyToken(token, tokenConfig.secretKey, (err, decoded) => {
    if(err) {
        res.status(200).send({"isAuthenticated": false});
      } else {
        res.status(200).send({"isAuthenticated": true});
    }
  });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});
// api to verify user
router.post('/login', (req, res, next) => {
  try {
    let userInfo =  req.body;
    
    userCtrl.verifyUser(userInfo).then((response) => {
      res.status(response.status).send(response);
    },
    (err) => {
      res.status(err.status).send({message:err.message});
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});
// api to verify user
router.get('/availableUser', (req, res, next) => {
  try {
    let userInfo =  req.query.id;
    console.log(req.query.id);
    userCtrl.availableUser(userInfo).then((response) => {
      res.status(response.status).send(response);
    },
    (err) => {
      res.status(err.status).send({message:err.message});
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});
module.exports = router;