let notesDAO = require('./notes.dao');
// handles to insert newly created note into the database
const addNote = (userId, note) => {
  return notesDAO.addNote(userId, note);
};
// handles to get all notes from database
const getNotes = (userId) => {
  return notesDAO.getNotes(userId);
};
// handles to update a note into the database
const updateNote = (noteId, editedNote) => {
  return notesDAO.updateNote(noteId, editedNote);
};
const sharedNotes = (userId) => {
  return notesDAO.sharedNotes(userId);
};

const deleteNote = (noteId) => {
  return notesDAO.deleteNote(noteId);
};

const getReminder = (userId) => {
  return notesDAO.getReminder(userId);
}

const saveReminder = (noteId, dueAt) => {
  return notesDAO.saveReminder(noteId, dueAt);
}

const removeReminder = (noteId) => {
  return notesDAO.removeReminder(noteId);
}
module.exports = {
  addNote,
  getNotes,
  updateNote,
  deleteNote,
  sharedNotes,
  getReminder,
  saveReminder,
  removeReminder
}