const notesService =  require('./notes.services');
// Handler to add a note into a database
const addNote = (userId, note) => {
  return notesService.addNote(userId, note);
}
// Handler to get notes
const getNotes = (userId) => {
  return notesService.getNotes(userId);
}
// Handler to update note
const updateNote = (noteId, editedNote) => {
  return notesService.updateNote(noteId, editedNote);
}

// Handler to delete note
const deleteNote = (noteId) => {
  return notesService.deleteNote(noteId);
}
// Handler to update note
const sharedNotes = (userId) => {
  return notesService.sharedNotes(userId);
}

const getReminder = (userId) => {
  return notesService.getReminder(userId);
}

const saveReminder = (noteId, dueAt) => {
  return notesService.saveReminder(noteId, dueAt);
}

const removeReminder = (noteId) => {
  return notesService.removeReminder(noteId);
}

module.exports = {
  addNote,
  getNotes,
  updateNote,
  deleteNote,
  sharedNotes,
  getReminder,
  saveReminder,
  removeReminder
}