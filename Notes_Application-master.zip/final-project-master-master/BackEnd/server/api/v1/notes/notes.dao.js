let noteModel = require('./notes.entity');
const uuidv1 = require('uuid/v1');
// Handles to insert newly created note into the database
const addNote = (userId, note) => {
  return new Promise((resolve, reject) => {
    let newNote = new noteModel();
    newNote.id = uuidv1();
    newNote.title = note.title;
    newNote.text = note.text;
    newNote.userId = userId;
    newNote.save((err, note) => {
      if(err) {
        console.log(err);
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({note: note, message: 'Note is added successfully', status:201});
      }
    });
});
};
// Handles to get all notes from database
const getNotes = (userId) => {
  return new Promise((resolve, reject) => {
    noteModel.find({ userId: userId }, (err, notes) => {
      if (err) {
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({notes: notes, status:200});
      }
    });
  })
};
// Handles to update a note into the database
const updateNote = (noteId, editedNote) => {
  return new Promise((resolve, reject) => {
    delete editedNote['_id'];
    delete editedNote['userId'];
    delete editedNote['createdOn'];
    delete editedNote['id'];
    editedNote['modifiedOn'] = new Date();
    noteModel.findOneAndUpdate({id: noteId}, editedNote, {new: true}, function(err, note) {
      if (err) {
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({updatedNote: note, message: 'Note is updated successfully', status: 200});
      }
    });
  });
};

const deleteNote = (noteId) => {
  console.log("delete note:"+ noteId);
  return new Promise((resolve, reject) => {    
    noteModel.deleteOne({id: noteId}, function(err) {
      if (err) {
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({ message: 'Note deleted successfully', status: 200});
      }
    });
  });
};

// Handles to get all shared notes from database
const sharedNotes = (userId) => {
  return new Promise((resolve, reject) => {
    noteModel.find({"sharewith":userId}, (err, notes) => {
      if (err) {
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({notes: notes, status:200});
      }
    });
  })
};

const getReminder = (userId) => {
  console.log()
  return new Promise((resolve, reject) => {
    noteModel.find({"userId":userId, $and: [{ dueAt : { $exists: true } }]} , (err, notes) => {
      if (err) {
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({notes: notes, status:200});
      }
    });
  })
};

const saveReminder = (noteId, dueAt) => {
  return new Promise((resolve, reject) => {
  console.log("note id:"+ noteId);
   console.log("note dueAt:"+ dueAt);

    noteModel.updateOne({ _id: noteId }, {
            "_id": noteId,
            "dueAt": dueAt,
        }, { upsert: true }).then(() => {
            noteModel.findOne({ _id: noteId }).then(note => {
                //note.id = note._id;
               // resp.status(200).header("Content-Type", "application/json").send(note);
                resolve({note: note, status:200});
            }).catch(err => {
               reject({message: err, status: 500});
               // resp.status(400).header("Content-Type", "application/json").send({ "message": err });
            });
        }).catch(err => {
            reject({messages: err, status: 500});
            //resp.status(400).header("Content-Type", "application/json").send({ "message": err });
        });
    
  })
}

const removeReminder = (noteId) => {
  return new Promise((resolve, reject) => {

    noteModel.updateOne({ _id: noteId }, {
            "_id": noteId,
            "dueAt": null,
        }, { upsert: true }).then(() => {
            Note.findOne({ _id: noteId }).then(note => {
                //note.id = note._id;
                 resolve({note: note, status:200});
            }).catch(err => {
                reject({message: 'Internal Server Error', status: 500});
            });
        }).catch(err => {
            reject({message: 'Internal Server Error', status: 500});
        });
  })
}


module.exports = {
  addNote,
  getNotes,
  updateNote,
  deleteNote,
  sharedNotes,
  getReminder,
  saveReminder,
  removeReminder
}