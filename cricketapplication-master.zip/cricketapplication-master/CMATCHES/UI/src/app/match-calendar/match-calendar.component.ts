import { ActivatedRoute, Router } from '@angular/router';
import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { CRICKET } from './../app.constants';
import { HomeService } from './../Services/home.service';
import { MatchesService } from './../Services/matches.service';

@Component({
  selector: 'app-match-calendar',
  templateUrl: './match-calendar.component.html',
  styleUrls: ['./match-calendar.component.css'],
  providers: [HomeService]
})
export class MatchCalendarComponent implements OnInit {
  matchCalendar: any;
  constructor(private homeservice: HomeService, public matchservice: MatchesService) { }

  ngOnInit() {
    this.homeservice.getMatchCalendar().subscribe(resp => {
      console.log("calendar", resp);
      this.matchCalendar = resp.response.data;
    });
  }

  addFav(m) {
      this.matchservice.saveFavMatches({matchId: m.unique_id, userId: localStorage.getItem('userid'), details: m}).subscribe(res => {
           console.log(res);
      });
  }

}
