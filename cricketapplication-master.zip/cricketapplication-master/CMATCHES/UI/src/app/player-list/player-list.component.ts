import { ActivatedRoute, Router } from '@angular/router';
import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { CRICKET } from './../app.constants';
import {HomeService} from './../Services/home.service';
import {PlayerFilterPipe } from './../Services/pipes';


@Component({
  selector: 'app-player-list',
  templateUrl: './player-list.component.html',
  styleUrls: ['./player-list.component.css'],
  providers: [HomeService],
})
export class PlayerListComponent implements OnInit {
  allPlayers: any = [];

   constructor(private homeservice: HomeService, private route: ActivatedRoute, private router: Router) {   }

  ngOnInit() {
    this.homeservice.getAllPLayers().subscribe( resp => { 
      console.log(resp.players);
      this.allPlayers = resp.players;
    });
  }


  goToPLayerDetails(pid) {
    console.log(pid);
    this.router.navigate([CRICKET.ROUTES.PLAYER], { queryParams: { playerIdSelected: pid  }
    });
  }
}
