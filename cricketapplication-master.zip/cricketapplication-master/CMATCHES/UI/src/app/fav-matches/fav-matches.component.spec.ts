import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FavMatchesComponent } from './fav-matches.component';

describe('FavMatchesComponent', () => {
  let component: FavMatchesComponent;
  let fixture: ComponentFixture<FavMatchesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FavMatchesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FavMatchesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
