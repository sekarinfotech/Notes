import { MatchesService } from './../Services/matches.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fav-matches',
  templateUrl: './fav-matches.component.html',
  styleUrls: ['./fav-matches.component.css']
})
export class FavMatchesComponent implements OnInit {
  favouriteMatches = [];
  stageArray = [];
  constructor(private svc: MatchesService) { }

  ngOnInit() {
    this.svc.getFavoriteMatches(localStorage.getItem('userid')).subscribe(response => {
      this.favouriteMatches = response.userInfo;
    });
  }
}