export const config = {
  matchesApiUrl: 'http://cricapi.com/api/',
    apiUrl: 'http://localhost:3000',
    matchesApiKey: 'DBtz097EGahknuihh3v4crgzAYG3'
  };
  