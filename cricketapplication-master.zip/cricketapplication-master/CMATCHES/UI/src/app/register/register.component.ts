import { Component } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Register } from '../models/registerDetails';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent {
  submitMessage: any;
  username = new FormControl('', [Validators.required]);
  password = new FormControl('', [Validators.required]);

  constructor(private httpClient: HttpClient, private router: Router) {}

  registerSubmit() {
    const loginData = new Register(this.username.value, this.password.value);
    console.log("entering:")
    const auth_url = 'http://localhost:3000/';
    if (this.username.valid && this.password.valid) {
      return this.httpClient.post(`${auth_url}api/v1/users/register`, loginData).subscribe(
        
        response => {
          // Set the token in localstorage
          console.log("Created:")
          localStorage.setItem('bearerToken', response['token']);
          this.router.navigate(['login']);
        },
        err => {
          // get the error message based on the status
          this.submitMessage = (err.status === 403) ? err.error.message : err.message ;
        }
      );
    }
  }
}