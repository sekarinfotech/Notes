export class Register {
  userId: string;
  password: string;
  constructor(userId, password) {
    this.userId = userId;
    this.password = password;
  }
}
