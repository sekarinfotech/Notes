export class matchesObject {
  matchId: string;
  userId: string;
  details: object;
}
