import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { matchesObject } from '../models/matchesObject';
import { config } from './../config';
import { User } from '../models/user';
const auth_url = 'http://localhost:3000';

@Injectable({
  providedIn: 'root'
})
export class MatchesService {
  constructor(private http: HttpClient) {}

  saveFavMatches(matches: matchesObject) {
    console.log(matches);
    return this.http.post<any>(`${auth_url}/api/v1/users/saveFavMatches`, matches);
  }

  getFavoriteMatches(userId: string) {
    return this.http.get<any>(`${auth_url}/api/v1/users/favorites?userId=${userId}`);
  }
}
