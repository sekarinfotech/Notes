import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { Router } from '@angular/router';
import { config } from './../config';

@Injectable({ providedIn: 'root' })
export class UserService {
  constructor(private router: Router, private http: HttpClient) {}

  getAll() {
    return this.http.get<User[]>(`${config.matchesApiUrl}/users`);
  }

  routeToRegister() {
    // route to login
    this.router.navigate(['register']);
  }
}
