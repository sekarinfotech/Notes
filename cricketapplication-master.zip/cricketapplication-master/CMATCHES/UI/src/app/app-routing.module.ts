import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { FavMatchesComponent } from './fav-matches/fav-matches.component';
import { CanActivateRouteGuard as AuthGuard } from './can-activate-route.guard';
import { HomeComponent } from './home/home.component';
import { MatchCalendarComponent } from './match-calendar/match-calendar.component';
import { NewMatchesComponent } from './new-matches/new-matches.component';
import { PlayerComponent } from './player/player.component';
import { PlayerListComponent } from './player-list/player-list.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path:'register',
    component: RegisterComponent
  },
   {
     path: 'home',
     component: HomeComponent,
     canActivate: [AuthGuard]
   },
  {
  path: 'favourites',
  component: FavMatchesComponent,
  canActivate: [AuthGuard]
  },
  {
    path: 'match-calendar',
    component: MatchCalendarComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'new-matches',
    component: NewMatchesComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'player',
    component: PlayerComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'playerList',
    component: PlayerListComponent,
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
