import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AuthenticationService } from './Services/authentication.service';

@Injectable()
export class CanActivateRouteGuard implements CanActivate {
  private auth_url = 'http://localhost:3000/';
  constructor(private authService: AuthenticationService, private router: Router, private http: HttpClient) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      // activate the routing based on user authentication
      const authPromise = this.isUserAuthenticated(localStorage.getItem('bearerToken'));
      return authPromise.then(isAuthenticated => {
        if (!isAuthenticated) {
          // if the user is not authenticated, route to login page
          this.router.navigate(['login']);
        }
        return isAuthenticated;
      });
    }

    // to validate if the user is authenticated or not
  isUserAuthenticated(token): Promise<boolean> {
      let header =new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.post(`${this.auth_url}api/v1/users/isAuthenticated`, {}, { headers: header }).pipe(map(response => response['isAuthenticated'])).toPromise();
  }


}
