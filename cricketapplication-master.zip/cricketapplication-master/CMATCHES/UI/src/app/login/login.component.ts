import { Component } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserService } from './../Services/user.service';
import { Register } from '../models/registerDetails';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent {
  submitMessage: any;
  username = new FormControl('', [Validators.required]);
  password = new FormControl('', [Validators.required]);

  constructor(private UserService: UserService, private httpClient: HttpClient, private router: Router) {}
  register() {
    this.UserService.routeToRegister();
  }

  loginSubmit() {
    const loginData = new Register(this.username.value, this.password.value);
    const auth_url = 'http://localhost:3000/';
    if (this.username.valid && this.password.valid) {
      return this.httpClient.post(`${auth_url}api/v1/users/login`, loginData).subscribe(
        response => {
          // Set the token in localstorage
          //this.authService.setBearerToken(response['token']);
          localStorage.setItem('bearerToken', response['token']);
          //this.authService.setUserID(response['user']['userId']);
          localStorage.setItem('userid', response['user']['userId']);
          //this.routerService.routeToDashboard();
          //TODO:Sekar
           this.router.navigate(['/home']);
        },
        err => {
          // get the error message based on the status
          this.submitMessage = (err.status === 403) ? err.error.message : err.message ;
        }
      );
    }
  }

}
