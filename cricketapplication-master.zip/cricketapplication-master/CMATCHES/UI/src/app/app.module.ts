import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  MatButtonModule,
  MatToolbarModule,
  MatCardModule,
  MatInputModule,
  MatDialogModule,
  MatTableModule,
  MatMenuModule,
  MatIconModule,
  MatProgressSpinnerModule,
  MatSidenavModule,
  MatPaginatorModule
} from '@angular/material';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { FavMatchesComponent } from './fav-matches/fav-matches.component';
import { CanActivateRouteGuard } from './can-activate-route.guard';

import { NguiAutoCompleteModule } from '@ngui/auto-complete';
import { CRICKET } from './app.constants';

import { HomeComponent } from './home/home.component';
import { PlayerComponent } from './player/player.component';
import { HomeService } from './Services/home.service';
import { PlayerFilterPipe } from './Services/pipes';
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import { PlayerListComponent } from './player-list/player-list.component';
import { NewMatchesComponent } from './new-matches/new-matches.component';
import { MatchCalendarComponent } from './match-calendar/match-calendar.component' ;

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    FavMatchesComponent,
    HomeComponent,
    PlayerComponent,
    HeaderComponent,
    FooterComponent,
    PlayerListComponent,
    NewMatchesComponent,
    MatchCalendarComponent,
    PlayerFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatToolbarModule,
    MatCardModule,
    MatInputModule,
    MatDialogModule,
    MatTableModule,
    MatMenuModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatSidenavModule,
    MatPaginatorModule,
    NguiAutoCompleteModule
  ],
  providers: [CanActivateRouteGuard, HomeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
