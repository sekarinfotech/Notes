let userModel = require('./user.entity');
let matchesModel = require('./matchesobject.entity');
let bcrypt = require('bcryptjs');
let uuid = require('uuid/v4');
const { tokenConfig } = require('../../Connection/appConfig');
var jwt = require('jsonwebtoken');

//Authentication 
var signToken = function (payload, secret, expireIn, callback) {
  jwt.sign(payload, secret, expireIn, callback);
}

var verifyToken = function (token, secret, callback) {
  jwt.verify(token, secret, callback)
}


function encrypt(val) {
  var salt = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(val, salt);
}

function verifyPassword(val, hash) {
  console.log('val : '+val);
  console.log('hash : '+hash);
  return bcrypt.compareSync(val, hash);
}

const findUser = (userInfo) => { 
  return new Promise((resolve, reject) => {
    userModel.findOne({ userName: userInfo.userName }, function(err, userObj) {
      if (err) {
        reject({message: 'Internal server error', status: 500});
      } else {
        if(!userObj) { reject({ message: 'You are not registered user', status: 403 }); }
        else { resolve({ user:userObj, message: 'user found', status: 200 }); }       
      }
    });
  });
};

function addUser(userInfo) {
  console.log(JSON.stringify(userInfo));
        return new Promise((resolve, reject) => {
          findUser(userInfo).then(
            (res) => {
              reject({message: 'username is already exist', status: 403});
            },
            (err) => { 
              let newUser = new userModel();
              newUser.userId = uuid();
              newUser.userName = userInfo.userName;
              newUser.password = encrypt(userInfo.password);
              newUser.save((err, userInfo) => {
                if(err) {
                  console.log("user failed..");
                  reject({message: 'Internal Server Error', status: 500});
                } else {
                  console.log("user added..");
                  resolve({ userInfo: {userName: userInfo.userName}, message: 'Registered successfully', status:201 });
                }
              });
            });
        });
     
  }

// Verifies user login data 
const verifyUser = (userInfo) => {
  console.log('router service');
  return new Promise((resolve, reject) => {
    findUser(userInfo).then(
      (res) => {
        if (!verifyPassword(userInfo.userId, res.user.password)) { 
          reject({message: 'Passwords is incorrect', status: 403}); 
        }
        else {
          signToken({userName:res.user.userId, userId:res.user.userId}, tokenConfig.secretKey, {expiresIn: '1h' }, (tokenErr, tokenRes) => {
            if(tokenErr) {
              reject({message: 'Internal Server Error', status: 500});
            }
            else {
              resolve({token: tokenRes, user:{ userName: res.user.userId, userId: res.user.userId}, status: 200 });
            }
          });          
        }
      },
      (err) => {
        if  (err.message === 'You are not registered user')
        { reject({ message: 'You are not registered user', status: 403 }); }
        else { reject(err); }
      });
  })
}

const saveFavMatches = (userInfo) => {
  return new Promise((resolve, reject) => {
    let matches = new matchesModel();
    matches.matchId = userInfo.matchId;
    matches.userId = userInfo.userId;
    matches.details = userInfo.details;
    matches.save((err, userInfo) => {
      if(err) {
        console.log(err);
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({userInfo: userInfo, message: 'Match favoiurted successfully', status:201});
      }
    });
});
}


const getFav = (userId) => {
  return new Promise((resolve, reject) => {    
    matchesModel.find({userId : userId} ,(err, userInfo) => {
      if(err) {
        console.log(err);
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({userInfo: userInfo, message: 'fav list', status:200});
      }
    });
});
}

module.exports = {
  addUser,
  verifyUser,
  verifyToken,
  saveFavMatches,
  getFav
}