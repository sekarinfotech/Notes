const router = require('express').Router();
const { tokenConfig } = require('../../Connection/appConfig');

const userService = require('./user.service');
// api to register new user
router.post('/register', (req, res, next) => {
  let userInfo = req.body;
  console.log("regsiter");
  try {
    userService.addUser(userInfo).then((response) => {
      res.status(response.status).send({userInfo:response.userInfo.userId});
    },
    (err) => {
      res.status(err.status).send({message:err.message});
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

// api to verify user
router.post('/login', (req, res, next) => {
  try {
    let userInfo =  req.body;
    console.log('router login');
      userService.verifyUser(userInfo).then((response) => {
      res.status(response.status).send(response);
    },
    (err) => {
      res.status(err.status).send({message:err.message});
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});
router.post('/isAuthenticated',(req, res, next) => {
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    userService.verifyToken(token, tokenConfig.secretKey, (err, decoded) => {
    if(err) {
        res.status(200).send({"isAuthenticated": false});
      } else {
        res.status(200).send({"isAuthenticated": true});
    }
  });
  } catch (err) {
    console.log(err);
    res.send({message: 'Failed to complete request'})
  }
});

router.post('/saveFavMatches',(req, res, next) => {
  let userInfo =  req.body;
  console.log("req body:" + JSON.stringify(userInfo));
  try {
    userService.saveFavMatches(userInfo).then((response) => {
      res.status(response.status).send(response);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

router.get('/favorites',(req, res, next) => {

  console.log("req query image id:" +req.query.userId);
  try {
    userService.getFav(req.query.userId).then((response) => {
      res.status(response.status).send(response);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});
module.exports = router;
