let mongoose = require('mongoose');
let Schema = mongoose.Schema;
const matchesobjectSchema = new Schema({
  matchId: {
    type: String,
    required: true
  },
  userId: {
    type: String,
    required: true
  },
  details: {
    type: Object,
    required: true
  },

});
module.exports = mongoose.model('matchesobject', matchesobjectSchema);