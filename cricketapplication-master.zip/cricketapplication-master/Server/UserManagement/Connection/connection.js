// write your db connection code here

let mongoose = require('mongoose');
// create mongo connection
function createMongoConnection() {
  console.log("Connecting to db..");
  mongoose.connect(process.env.MONGO_URL || "mongodb://localhost:27017/cmatches");
}
module.exports = {
  createMongoConnection
}